<?php

$sarkdb = "sqlite:/opt/sark/db/sark.db";
$sarkpath = '/opt/sark'; 

?>
