<?php


$sarkdb = "/opt/sark/db/sark.db"; 

?>
