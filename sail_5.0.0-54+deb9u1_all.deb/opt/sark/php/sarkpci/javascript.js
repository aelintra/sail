
  $(document).ready(function() {
	$('#pagetabs').tabs();        
  });
 

      
