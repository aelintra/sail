	
<div class="banner">
<?php
if (file_exists($_SERVER["DOCUMENT_ROOT"] . "/sark-common/Top_Banner-SARK_UCS.gif")) { 
	echo '<img src="/sark-common/Top_Banner-SARK_UCS.gif">' . PHP_EOL;
}
else { 
	echo '<img src="/sark-common/Top_Banner_sail.gif"  alt="SARK UCS">' . PHP_EOL;
} 
?>
</div>
