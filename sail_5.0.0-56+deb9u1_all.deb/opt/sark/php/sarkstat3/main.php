<?php
 	include $_SERVER["DOCUMENT_ROOT"] . "../php/srkhead.php";
	require $_SERVER["DOCUMENT_ROOT"] . "../php/banner.php";
	require $_SERVER["DOCUMENT_ROOT"] . "../php/navigation.php";
?>
<div class="guest">
	<iframe src="/stat/?s=3" ></iframe>
</div>
</div>

