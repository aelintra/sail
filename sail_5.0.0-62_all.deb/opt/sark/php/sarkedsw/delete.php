<?php

  $id = $_REQUEST['id'] ;
  echo "ok";

?>
