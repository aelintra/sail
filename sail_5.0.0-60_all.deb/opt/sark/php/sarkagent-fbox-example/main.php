
<?php 
	require_once $_SERVER["DOCUMENT_ROOT"] . "../php/srkmain.php"; 
?>
