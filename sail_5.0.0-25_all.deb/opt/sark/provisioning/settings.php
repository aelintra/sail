<?php

$rootPath = "/opt/sark/db";

$dBFullPath = $rootPath . "/sark.db";

$checkUA = false;

?>
