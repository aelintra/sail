
  $(document).ready(function() {
	$('body').css('display', 'none');

	$('body').fadeIn(1000);
                 
 });
 

      
