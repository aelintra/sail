{ "aaData": [
	["1","Internet Explorer 4.0","Win 95+","4","X","1"],
	["2","Internet Explorer 5.0","Win 95+","5","C","2"],
	["3","Internet Explorer 5.5","Win 95+","5.5","A","3"],
	["4","Internet Explorer 6","Win 98+","6","A","4"],
	["5","Internet Explorer 7","Win XP SP2+","7","A","5"],
	["6","AOL browser (AOL desktop)","Win XP","6","A","6"]
	
] }